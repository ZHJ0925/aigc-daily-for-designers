---
name: aihot-designer-daily
description: >
  Generate a single-file HTML dashboard for the "UIUX Designer AIGC Daily Report"
  (UIUX 设计师 AIGC 日报). This skill should be used when the user asks for
  a designer-focused AI daily report, AIGC morning briefing for designers,
  or a visual dashboard of AI news curated for UI/UX / product designers,
  with Baoding weather info.
  It fetches data from the AI HOT daily API, supplements with Chinese design
  media (优设网, 量子位, 极客公园), filters for designer-relevant content,
  and outputs a polished single-file HTML dashboard with QClaw-style dark theme
  (glass-morphism cards, floating AI icons, horizontal gradient title, circular
  numbered badges).
agent_created: true
---

# UIUX Designer AIGC Daily Report

Generate a single-file HTML morning dashboard for UIUX/product designers,
curating AI news from the AI HOT daily API and Chinese design media with
designer-oriented summaries and insights.

## When to Use

Trigger when the user asks for:
- "UIUX 设计师 AIGC 日报"
- "设计师晨报" / "设计日报"
- "AIGC design daily report"
- Any request combining "designer" + "AI daily/news" + "dashboard/HTML"

## Workflow

### 1. Fetch Data from AI HOT API

Default to `items?mode=selected + since=<24h ago>` for always-fresh curated data.
Only use the `daily` endpoint when the user explicitly wants a specific date's
daily archive (e.g. "看下 6 月 10 号的日报").

```bash
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

# Default: rolling 24h curated selection (always fresh)
since=$(date -u -v-24H +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '24 hours ago' +%Y-%m-%dT%H:%M:%SZ)
curl -sH "User-Agent: $UA" "https://aihot.virxact.com/api/public/items?mode=selected&since=$since&take=50"
```

Response structure (items endpoint):
- `items[]`: each with `id`, `title`, `url`, `source`, `publishedAt`, `summary`, `category`, `score`, `selected`
- `category` values: `ai-models`, `ai-products`, `industry`, `paper`, `tip`
- **`url` is the real source URL** — use it directly as the card link href, NOT `https://aihot.virxact.com`

### 1b. Fetch Baoding Weather

```bash
curl -s "https://uapis.cn/api/v1/misc/weather?city=保定"
```

Map `weather` to an icon: 晴→☀ 多云→☁ 阴→☁ 雨→🌧 雪→❄ 雾→🌫 霾→🌫.
Display format: `保定 · {weather} {temperature}°C · {wind_direction}{wind_power} · 湿度{humidity}%`

### 1c. Supplement with Chinese Design Media

Search and fetch today's articles from Chinese design/AI media to ensure coverage
of domestic design tool news. Use WebSearch + WebFetch for these sources:
- **优设网 (uisdc.com)**: design tools, UI/UX tutorials, Figma updates
- **量子位 (qbitai.com)**: AI industry news with China focus
- **极客公园 (geekpark.net)**: tech product and design trends

Add relevant design-focused articles to the pool before filtering.

### 2. Filter for Designer Relevance

Keep items with clear relevance to UIUX/product design. Aim for 8-15 items.

**High priority (keep):**
- Image/video generation model updates (multimodal, visual AI)
- AIGC design tools, creative tools, product tool updates
- AI applications in UI, UX, product design, brand visuals, content production
- Design-relevant trends, new paradigms, new interactions
- Papers/viewpoints/methodologies related to design, creative production

**Low priority (skip or minimize):**
- Pure developer tools (Claude Code versions, Codex dev mode)
- LLM evaluation benchmarks
- Infrastructure/rate-limit changes
- Items with zero design workflow connection

### 3. Write Designer-Oriented Content

For each kept item, write:
- **Title**: lightly optimize for readability in Chinese, preserve original meaning
- **Summary**: ≤60 Chinese characters, explain "what this means for design work"
- **Designer insight**: one sentence on specific value for UIUX/product design workflow

Time formatting: convert to Beijing-time human-readable format
("今天上午 09:48", "昨天", "昨天晚上 21:10", "2 小时前"). Never show raw ISO strings.

### 4. Generate HTML Dashboard

Use the template in `assets/dashboard-template.html` as the visual foundation.
The template implements a QClaw-style dark theme with the following design system:

**Design Theme — QClaw Dark:**
- Background: #0a0a0f deep dark with red-accent grid pattern
- Accent: #ff3b30 (brand red) with #ff6b5e glow variant
- Cards: glass-morphism (hsla white translucent, backdrop-filter blur)
- Ambient: 3 floating blurred orbs + 11 animated SVG decorative icons (sparkles, neural nodes, code brackets)
- Inherently dark — no light/dark mode switching

**Hero:**
- Horizontal gradient title: `linear-gradient(90deg, #ffffff → #ff9e94 → #ff3b30)` with background-clip: text
- Centered hero badge, pulsating radial glow background
- Brief bar (horizontal stats card inside hero) with gradient number

**TOC:**
- Sticky nav bar with horizontal links
- Order matches section display order (content first, empty last)

**Cards:**
- Glass-morphism background, red gradient glow on hover, translateY(-6px) lift
- Staggered fadeUp animation (0.04s delay increments)
- Circular numbered badges: 26px red gradient circle with white bold number
- Color-coded section tags: models(red), products(blue), industry(orange), paper(purple), tip(green)

**Numbering — Per-section independent:**
Each section's cards start from 01. Do NOT use global sequential numbering.
A section with 3 items shows 01, 02, 03 regardless of other sections.

**Section ordering:**
1. Content sections (those with ≥1 items) come first
2. Empty sections (0 items) go at the bottom
3. Within each group, follow the standard order: products → industry → tip → models → paper

**Empty section placeholder:**
When a section has 0 items, still include it at the bottom with:
```html
<div class="empty-card">
  <div class="empty-icon">🤖</div>
  <p class="empty-text">今日暂无 · 板块描述</p>
</div>
```
Use dashed border (1px dashed hsla white 8%), centered layout, low-opacity emoji.

**Section icons:**
Each section header includes an inline SVG decorative icon (36×36 viewBox)
matching the section's theme color. Use the icons defined in the template.

**Hero title format:** `YYYY.M.D 的 AIGC 设计日报`

**Brief bar layout (horizontal, inside hero):**
```html
<aside class="brief-card">
  <p class="brief-label">Today's Brief</p>
  <div class="brief-number">N</div>
  <p class="brief-unit">条精选资讯</p>
  <div class="brief-stats">
    <span class="brief-stat"><strong>N</strong> 模型</span>
    <span class="brief-stat"><strong>N</strong> 产品</span>
    <span class="brief-stat"><strong>N</strong> 行业</span>
    <span class="brief-stat"><strong>N</strong> 论文</span>
    <span class="brief-stat"><strong>N</strong> 观点</span>
  </div>
  <div class="brief-weather">
    <span class="weather-icon">☁</span>
    <span class="weather-info">保定 · 多云 29°C · 西南风4级 · 湿度46%</span>
  </div>
  <div class="brief-footer">报告窗口 MM.DD–MM.DD · 生成 HH:mm</div>
</aside>
```

**Card structure per item:**
```html
<article class="card">
  <div class="card-top">
    <span class="card-num">NN</span>
    <span class="card-section-tag tag-xxx">版块标签</span>
    <span class="card-source">来源名称</span>
    <span class="card-time">人话时间</span>
  </div>
  <h3 class="card-title">标题</h3>
  <p class="card-summary">60字以内中文摘要</p>
  <p class="card-insight">设计师看点一句话</p>
  <a class="card-link" href="URL" target="_blank" rel="noopener noreferrer">查看原文</a>
</article>
```

Tag classes: `tag-models` (红), `tag-products` (蓝), `tag-industry` (橙), `tag-paper` (紫), `tag-tip` (绿).

**Link handling (CRITICAL — WeChat Mini Program webview compatible):**
- Use `<a>` tags with `href`, `target="_blank"`, `rel="noopener noreferrer"`
- **CSS fix**: `.card::before` and `.card::after` MUST have `pointer-events: none`, otherwise the decorative pseudo-elements intercept all click events on child elements
- JavaScript: Try `window.open(url, '_blank')` first for direct navigation
- If `window.open()` is blocked (e.g. in Mini Program webview), fall back to modal popup with clipboard copy
- Modal CSS/JS must be included before `</body>` (see template for full implementation)
- Required additional CSS for `.card-link`: `cursor: pointer; text-decoration: none;`

### 5. Output

Write the complete single-file HTML to `~/Desktop/AI日报/YYYY.M.D日报.html`.
Preview with `preview_url` and deliver with `deliver_attachments`.

## Constraints

- Pure HTML/CSS single file, all inline, no external resources
- System font stack only
- CSS variables for theme colors
- Responsive layout (desktop + mobile)
- All links: `target="_blank" rel="noopener noreferrer"`
- Times must be Beijing-time human-readable, never ISO strings
- Per-section independent numbering (each section starts from 01)
- Empty sections placed below content sections
